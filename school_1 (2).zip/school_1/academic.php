<?php
    include('header.php');
?>
<!--------------para 1------------------>
<div class="background2">
    <p class="glory2 text-light px-5">
        <b>Curriculum</b><br>
        <b class="bg-danger mt-2" style="width: 55%; height: 5px; display: block;"></b>
        <span class="p04" style="font-size:20px;">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Id, provident!</span>
    </p>
</div>
<!--------------para 2------------------>

<div class="p02">
    <p>
       Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis excepturi porro corporis similique voluptate iusto, natus autem ratione repudiandae architecto quasi quae impedit dolore expedita, at beatae voluptatem iure voluptatibus distinctio facere sed nesciunt voluptates quod. Esse debitis, incidunt corporis nesciunt at voluptatem adipisci cupiditate amet aperiam nostrum blanditiis ullam!
    </p>
</div>
<!--------------para 3------------------>

<h1 class="text-center mt-5"><b class="text-danger">Curriculum </b><b>Standards</b></h1>
<div class="row justify-content-center">
    <div class="col-sm-3 bg-danger text-light p-5 mx-2">
        <h1><b>4</b></h1>
        <p>AP exams in core subjects required to graduate</p>
    </div>
    <div class="col-sm-3 p-5 mx-2" style="background:#ecf0f1;">
    <h1><b>7.5</b></h1>
    <p>Total hours/week spent in chemistry, physics, and biology in grades 6–8</p>

    </div>
    <div class="col-sm-3 bg-dark text-light p-5 mx-2">
    <h1><b>2</b></h1>
    <p>Minimum hours/week teachers reserve for after school student support</p>
    </div>
</div>
</div>
<!--------------para 4------------------>

<div class="bg-color3 my-5 p-5">
    <h1><b>Education Redefined</b></h1>
    <b class="bg-light mb-3" style="width: 20%; height: 5px; display: block;"></b>
   <b class="mb-3"> <p>At GLORY Independent Schools, we’re proud to contribute to the tradition of excellence, one of putting student learning first and creating an environment of supportive collegiality between students, teachers, and administration. Education redefined rests on three pillars:</p>
</b>
<p>
<b><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-double-right" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M3.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L9.293 8 3.646 2.354a.5.5 0 0 1 0-.708"/>
  <path fill-rule="evenodd" d="M7.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L13.293 8 7.646 2.354a.5.5 0 0 1 0-.708"/>
</svg>&nbsp;A curriculum educating students to the highest international levels</b></p>

<p><b><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-double-right" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M3.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L9.293 8 3.646 2.354a.5.5 0 0 1 0-.708"/>
  <path fill-rule="evenodd" d="M7.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L13.293 8 7.646 2.354a.5.5 0 0 1 0-.708"/>
</svg>&nbsp;Expert teachers who are knowledgeable, passionate, and believe that with the right support and encouragement, any child can excel</b></p>

<p><b><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-double-right" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M3.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L9.293 8 3.646 2.354a.5.5 0 0 1 0-.708"/>
  <path fill-rule="evenodd" d="M7.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L13.293 8 7.646 2.354a.5.5 0 0 1 0-.708"/>
</svg>&nbsp;A joyful learning culture where hard work is celebrated and intellectual pursuits result in extraordinary outcomes</b></p>

</div>
<!--------------para 5------------------>

<div class="container-fluid pt-5 pb-3 text-center">
<h1 class="ps-3"><b>Disciplines</b></h1>
<b class="bg-danger mb-3 m-auto" style="width: 20%; height: 5px; display: block;"></b>
</div>

<div class="row justify-content-center">
        <!-- Program 1 -->
        <div class="col-sm-4 m-2">
            <div class="position-relative">
                <img src="image/c1.jpg" alt="Primary Program" class="img-fluid img1">
                <div class="phide">
                    <h5><b>Humanities</b></h5>
                    <div class="bg-danger"></div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque assumenda esse explicabo itaque perspiciatis sunt quisquam, magnam atque, recusandae quasi qui rerum!</p>
                </div>
            </div>
        </div>
        <!-- Program 2 -->
        <div class="col-sm-4 m-2">
            <div class="position-relative">
                <img src="image/c2.jpg" alt="Middle School Program" class="img-fluid img1">
                <div class="phide">
                    <h5><b>Math & Science</b></h5>
                    <div class="bg-danger"></div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque assumenda esse explicabo itaque perspiciatis sunt quisquam, magnam atque, recusandae quasi qui rerum!</p>
                </div>
            </div>
        </div>
        <!-- Program 3 -->
        <div class="col-sm-4 m-2">
            <div class="position-relative">
                <img src="image/c3.jpg" alt="High School Program" class="img-fluid img1">
                <div class="phide">
                    <h5><b>Interdisciplinary Studies</b></h5>
                    <div class="bg-danger"></div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque assumenda esse explicabo itaque perspiciatis sunt quisquam, magnam atque, recusandae quasi qui rerum!</p>
                </div>
            </div>
        </div>
         <!-- Program 4 -->
         <div class="col-sm-4 m-2">
            <div class="position-relative">
                <img src="image/c4.jpg" alt="High School Program" class="img-fluid img1">
                <div class="phide">
                    <h5><b>Physical Education</b></h5>
                    <div class="bg-danger"></div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque assumenda esse explicabo itaque perspiciatis sunt quisquam, magnam atque, recusandae quasi qui rerum!</p>
                </div>
            </div>
        </div>
         <!-- Program 5 -->
         <div class="col-sm-4 m-2">
            <div class="position-relative">
                <img src="image/ar.jpg" alt="High School Program" class="img-fluid img1">
                <div class="phide">
                    <h5><b>The Arts</b></h5>
                    <div class="bg-danger"></div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque assumenda esse explicabo itaque perspiciatis sunt quisquam, magnam atque, recusandae quasi qui rerum!</p>
                </div>
            </div>
        </div>
    </div>


<!--------------para 6----------------->
<div class="row bg-color p-5 mt-5">
    <div class="col-sm-6">
        <h3><b class="text-danger">Self-Advocacy & Autonomy</b></h3>
        <b class="bg-danger mb-3" style="width: 20%; height: 5px; display: block;"></b>
        <div>
            <p>
                Building a sense of belonging through meaningful connections and collaborations.
            </p>
            <p class="moreText" style="display: none;">
                We emphasize the importance of community values at GLORY International Schools. Our students grow up as part of a diverse, 
                inclusive, and respectful environment. Collaborating on projects, participating in events, and engaging in community services 
                help them become responsible global citizens.
            </p>
            <button class="toggleButton b1">Read More</button>
        </div>
    </div>
    <div class="col-sm-1"></div>
    <div class="col-sm-5 bg-danger pb-4 mt-5" style="height:250px;">
        <img src="image/c4.webp" alt="" width="100%" style="margin-top:-40px; margin-left:-30px;">
    </div>
</div>

<script>
     document.querySelectorAll(".toggleButton").forEach(function(button) {
        button.onclick = function () {
            const moreText = this.previousElementSibling;
            if (moreText.style.display === "none") {
                moreText.style.display = "block";
                this.innerText = "Read Less";
            } else {
                moreText.style.display = "none";
                this.innerText = "Read More";
            }
        };
    });
</script>
<?php
    include('footer.php');
?>