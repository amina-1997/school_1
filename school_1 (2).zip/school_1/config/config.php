<?php
define("SERVER", "localhost");
define("USERNAME", "amina");
define("PASSWORD", "amina2kk");
define("DATABASE_NAME", "school");

?>