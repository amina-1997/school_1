<?php
    include('config.php');

    class Database{
        public $server_name = SERVER;
        public $username = USERNAME;
        public $password = PASSWORD;
        public $db_name = DATABASE_NAME;

        public $error;
        public $conn;

        public function __construct(){
            $this->dbconnect();
        }

         public function dbconnect(){ 

        $this->conn = mysqli_connect($this->server_name, $this->username, $this->password, $this->db_name);
        if($this->conn){

        }else{
            $this->error="database connection failed";
            return false;
        }
    }

    public function insert($sql){
        $result = mysqli_query($this->conn, $sql)or die ($this->conn->error.__LINE__);
        if($result){
            return $result;
        }else{
            return false;
        }
    }
}
?>