<?php
    include('header.php');
?>
<div class="background" style="background-image:url('banner/acb3.jpg');">
    <p class="glory text-light">
        <b>International Performance</b><br>
        <b class="bg-danger mt-3" style="width: 50%; height: 5px; display: block;"></b>
    </p>
</div>

<div class="p02">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam fuga sit in iure amet sed dolores dicta suscipit saepe ipsum incidunt fugit accusamus, debitis, corrupti molestiae earum voluptate nulla, voluptatibus molestias odit placeat? Adipisci, animi atque! Error, blanditiis labore officia, amet ut voluptatem in, vel aliquid minima accusamus modi nihil recusandae numquam unde reprehenderit facilis ad fuga totam. Harum optio doloremque rem error distinctio, deserunt veritatis? Nobis, dicta. Atque repellat quisquam voluptatem cupiditate aliquid maiores, quae illum nobis autem soluta consequuntur quos asperiores voluptas porro quia alias. Tenetur dolorum voluptatibus, quod sunt consectetur dignissimos. Fugit harum excepturi minima quaerat illum.

    </p>
</div>
<div class="row ms-4 mt-5">
    <div class="col-sm-6">
        <h3><b class="text-danger">Leading the World in Math,Reading, and Science</b></h3>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Illo quasi laborum excepturi doloremque, ab facere enim aut inventore id eos, ratione mollitia non, odit neque architecto ipsum qui minus nemo necessitatibus aliquam cupiditate culpa rem? Nobis cupiditate, atque tempora vero veniam perspiciatis enim porro? Ad, sapiente? Fugit eum ratione velit?
        </p>
    </div>
        <div class="col-sm-4 ms-5">
            <img src="image/abp3.jpg" alt="">
        </div>
</div>


<div class="background mt-5" style="background-image:url('banner/acb2.jpg');">
    <p class="glory text-light">
        <b>College Admissions</b><br>
        <b class="bg-danger mt-3" style="width: 50%; height: 5px; display: block;"></b>
    </p>
</div>

<div class="p02">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam fuga sit in iure amet sed dolores dicta suscipit saepe ipsum incidunt fugit accusamus, debitis, corrupti molestiae earum voluptate nulla, voluptatibus molestias odit placeat? Adipisci, animi atque! Error, blanditiis labore officia, amet ut voluptatem in, vel aliquid minima accusamus modi nihil recusandae numquam unde reprehenderit facilis ad fuga totam. Harum optio doloremque rem error distinctio, deserunt veritatis? Nobis, dicta. Atque repellat quisquam voluptatem cupiditate aliquid maiores, quae illum nobis autem soluta consequuntur quos asperiores voluptas porro quia alias. Tenetur dolorum voluptatibus, quod sunt consectetur dignissimos. Fugit harum excepturi minima quaerat illum.

    </p>
</div>

<h3 class="text-center text-danger"><b>Class of 2024 Acceptance Rates</b></h3>
<div class="row justify-content-center">
    <div class="col-sm-2 bg-dark text-light p-2 m-2">
        <h1>23%</h1>
        <p>of our graduates are accepted to the top 10 colleges*</p>
    </div>

    <div class="col-sm-2 p-2 m-2" style="background:#ecf0f1;">
        <h1>41%</h1>
        <p>of our graduates are accepted to the top 20 colleges*</p>
    </div>

    <div class="col-sm-2 bg-danger text-light p-2 m-2">
        <h1>56%</h1>
        <p>of our graduates are accepted to the top 25 colleges*</p>
    </div>

    <div class="col-sm-2 p-2 m-2" style="background:#ecf0f1;">
        <h1>88%</h1>
        <p>of our graduates are accepted to the top 50 colleges*</p>
    </div>
</div>

<h3 class="text-center text-danger mt-5"><b>Class of 2024 Results</b></h3>

<div class="row justify-content-center">
    <div class="col-sm-3 bg-danger text-light m-2 p-5">
        <h1>1487</h1>
        <p>is the average SAT score out of 1600</p>
    </div>
    <div class="col-sm-3 m-2 p-5" style="background:#ecf0f1;">
        <h1>33</h1>
        <p>is the average ACT score out of 36</p>
    </div>
</div>

<?php
    include('footer.php');
?>