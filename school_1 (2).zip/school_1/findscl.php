<?php
    include('header.php');
?>

<div class="background mt-5" style="background-image:url('banner/fb.jpg');">
    <p class="glory text-light">
        <b>Find Your School</b><br>
        <b class="bg-danger mt-3" style="width: 50%; height: 5px; display: block;"></b>
    <b class="text-light" style="font-size:18px;">Find the BASIS Independent School nearest to you</b>

    </p>
</div>
<div class="p02">
    <p>
   GLORY Schools is a national network of PreK–12 private, secular schools that educate students to the highest international levels, located in some of the most bustling, dynamic metropolitan areas in the country. Find the school nearest to you
    </p>
</div>

<h1 class="text-center mt-5"><b>GLORY Schools Location</b></h1>
<b class="bg-danger mt-3 m-auto mb-5" style="width: 70%; height: 8px; display: block;"></b>

<div class="row mx-5">
    <div class="col-sm-3 mt-5">
    <h3><b> GLORY School</b></h3>
    <p> 1234, Elm Street,<br>
    Dhaka, Bangladesh<br>
    +880-1234-567890</p>
    </div>

    <div class="col-sm-3 mt-5">
        <img src="image/OIP.jpeg" alt="" width="100%">

    </div>
    <div class="col-sm-6">
    <div id="map" style="width: 100%; height: 300px;"></div>

    </div>
</div>
<?php
    include('footer.php');
?>

<script>
   var map = L.map('map').setView([23.8103, 90.4125], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
}).addTo(map);

L.marker([23.8103, 90.4125]).addTo(map)
    .bindPopup('Dhaka, Bangladesh')
    .openPopup();

</script>
