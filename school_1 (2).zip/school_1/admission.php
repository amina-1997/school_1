<?php
    include('header.php');
    include('config/database.php');
    $db = new Database();
    $message="";

    if(isset($_POST['submit'])){
        //parent section--------------------
        $parent_fname=$_POST['pfname'];
        $parent_lname=$_POST['plname'];
        $parent_email=$_POST['email'];
        $parent_phone=$_POST['phone'];
        $zip=$_POST['zip'];
        $campus=$_POST['campus'];

        //student section--------------------
        $first_name=$_POST['first-name'];
        $last_name=$_POST['last-name'];
        $age=$_POST['age'];
        $grade=$_POST['grade'];
        $comments=$_POST['comments'];

        //photo processing-----------------

        $permitted=array('jpg', 'png', 'jpeg');
        $photo_name=$_FILES["photo"]["name"];
        $photo_size=$_FILES["photo"]["size"];
        $photo_tmp=$_FILES["photo"]["tmp_name"];

        $div= explode('.', $photo_name);
        $file_extension= strtolower(end($div));
        $unique_name= substr(md5(time()), 0, 8).'.'. $file_extension;

        $upload_photo="admin/upload/".$unique_name;

        if(empty($parent_fname)|| empty($parent_lname)|| empty($parent_email)|| empty($parent_phone)||
        empty($zip)|| empty($campus)|| empty($first_name)|| empty($last_name)|| empty($age)||
        empty($grade)|| empty($comments)|| empty($photo_name)){
            $message= "fields must not be empty!";

        }elseif($photo_size > 1048576){
            $message="file size must be less than 1mb";
        }elseif(in_array($file_extension, $permitted)==false){
            $message = "you can only upload jpg, png and jpeg format image";
        }else{
            move_uploaded_file($photo_tmp, $upload_photo);

            $sql="insert into admission_form(pfirst_name, plast_name, p_email, P_phone, zip, Campus, fname, 
            lname, age, grade,comment, photo, date) values('$parent_fname', '$parent_lname', '$parent_email',
            '$parent_phone', '$zip', '$campus', '$first_name', '$last_name', '$age', '$grade', '$comments',
            '$upload_photo', NOW())";

            $result = $db->insert($sql);
            if($result){
                $message="inserted successfully";
            }else{
                $message="process failed";
            }

        }




    }

    if(empty($message)){

    }else{
        echo" <script>
            alert('$message');
        </script>";
    }
?>


<div class="background" style="background-image:url('image/b1.jpg'); margin-top:85px;">
    <p class="glory text-light text-center">
        <b>Enroll Now</b><br>
        <b class="bg-danger d-inline-block" style="width: 80%; height: 5px;"></b><br>
        <b class="text-light" style="font-size:18px;">To learn more about our programs or admissions process, please complete the form below.</b>
    </p>
</div>

<div class="background-section mt-5 container">
    <h1 class="mt-5 ms-3">Parent/Guardian Information</h1>
   
    <form method="post" action="" enctype="multipart/form-data">

        <!-- Parent/Guardian Information -->
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="fname">First Name *</label>
                <input type="text" id="fname" name="pfname" class="form-control" placeholder="Jane">
            </div>
            <div class="col-md-6">
                <label for="lname">Last Name *</label>
                <input type="text" id="lname" name="plname" class="form-control" placeholder="Doe">
            </div>
        </div>
        
        <div class="mb-3">
            <label for="email">Email Address *</label>
            <input type="email" id="email" name="email" class="form-control" placeholder="jane@gmail.com">
        </div>

        <div class="mb-3">
            <label for="phone">Phone Number *</label>
            <input type="tel" id="phone" name="phone" class="form-control" placeholder="555-478-2648">
        </div>

        <div class="mb-3">
            <label for="zip">Zip Code *</label>
            <input type="text" id="zip" name="zip" class="form-control" placeholder="61354">
        </div>

        <div class="mb-3">
            <label for="campus">Preferred Campus *</label>
            <select id="campus" name="campus" class="form-select">
                <option>Please select one</option>
                <option>Campus A</option>
                <option>Campus B</option>
            </select>
        </div>

        <!-- Student Information -->
        <h2>Student Information</h2>
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="first-name">Student First Name *</label>
                <input type="text" id="first-name" name="first-name" class="form-control" placeholder="John">
            </div>
            <div class="col-md-6">
                <label for="last-name">Student Last Name *</label>
                <input type="text" id="last-name" name="last-name" class="form-control" placeholder="Doe">
            </div>
        </div>

        <div class="mb-3">
            <label for="age">Student Age *</label>
            <input type="number" id="age" name="age" class="form-control" placeholder="10">
        </div>

        <div class="mb-3">
            <label for="grade">Student Grade *</label>
            <select id="grade" name="grade" class="form-select">
                <option>Select Grade</option>
                <option>1st Grade</option>
                <option>2nd Grade</option>
                <option>3rd Grade</option>
                <option>4th Grade</option>
                <option>5th Grade</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="photo">Student photo *</label>
            <input type="file" id="photo" name="photo" class="form-control">
        </div>
        <!-- Comment Box -->
        <h2>Additional Information</h2>
        <div class="mb-3">
            <label for="comments">Comments or Questions</label>
            <textarea id="comments" name="comments" rows="4" class="form-control" placeholder="Enter your comments or questions here"></textarea>
        </div>

        <button type="submit" name="submit" class="btn btn-light text-dark py-2 px-5 submit">
            Submit
        </button>
    </form>
</div>

<style>
    .submit {
        transition: background-color 0.3s ease, color 0.3s ease;
    }

    .submit:hover {
        background-color: #b71540;
        color: white; 
    }

    .background-section {
        padding: 20px;
        background-color: #f8f9fa;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .form-control, .form-select {
        border-radius: 5px;
    }
</style>

<?php
    include('footer.php');
?>
